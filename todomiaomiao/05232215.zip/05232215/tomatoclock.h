#ifndef TOMATOCLOCK_H
#define TOMATOCLOCK_H

#include <QWidget>
#include <QMouseEvent>
#include <QTimer>
#include <QTime>
#include <QPainter>
QT_BEGIN_NAMESPACE
namespace Ui { class TomatoClock; }
QT_END_NAMESPACE

class TomatoClock : public QWidget
{
    Q_OBJECT

public:
    TomatoClock(QWidget *parent = nullptr);
    ~TomatoClock();
protected:
    void mousePressEvent(QMouseEvent *e); //鼠标单击事件
    void mouseMoveEvent(QMouseEvent *e); // 鼠标单击拖动窗口
    void paintEvent(QPaintEvent *event) ;

private slots:
    void on_closeButton_clicked();
    void initTime(); //初始化时间
    void updateTime(); //更新时间
signals:
    void windowClosed();

private:
    int boundaryWidth;
    float Opacity;
    QPoint clickPos;
    Ui::TomatoClock *ui;
    QString current_color;
    QTimer *timer;
    QTime time;
    int state;//暂停or开始
    int tomato_num;
    int progress;
};
#endif // TOMATOCLOCK_H



