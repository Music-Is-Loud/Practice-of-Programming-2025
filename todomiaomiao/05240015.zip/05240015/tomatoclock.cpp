#include "tomatoclock.h"
#include "ui_tomatoclock.h"
#include <QDebug>
TomatoClock::TomatoClock(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::TomatoClock)
{
    ui->setupUi(this);
    boundaryWidth=4;                                    //设置触发resize的宽度
    Opacity = 0.8;
    current_color = "background:#CD9B9B";
    this->setWindowFlags(Qt::FramelessWindowHint);      //设置为无边框窗口
    this->setMinimumSize(45,45);                        //设置最小尺寸
    this->setStyleSheet(current_color);                 //设置背景颜色
    this->setWindowOpacity(Opacity);                    //设置不透明度
    state = 1;//1pause
    tomato_num = 1;
    timer = new QTimer;
    ui->Timer->setDigitCount(5);
    initTime();
    timer->setInterval(1000);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateTime()));
    timer->start();
    progress = 0;
}
TomatoClock::~TomatoClock()
{
    delete ui;
}



void TomatoClock::mousePressEvent(QMouseEvent *e)
{
    if(e->button()==Qt::LeftButton)
        clickPos=e->pos();
    //Opacity = 0.5;
    this->setWindowOpacity(Opacity);
    if (state == 1){
        //暂停
        state = 0;
        this->setStyleSheet("background:#B5B5B5");    //设置暂停背景颜色
        Opacity = 0.4;
        timer->stop();
        this->setWindowOpacity(Opacity);                    //设置不透明度
    }else{//恢复
        state = 1;
        timer->start();
        this->setStyleSheet( current_color);          //恢复背景颜色
        Opacity = 0.8;
    }
    this->setWindowOpacity(Opacity);                    //设置不透明度
}

void TomatoClock::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    // 计算绘制参数
    int side = qMin(width(), height()) - 60; // 留出边距
    float angle;
    QRectF rect(30, 30, side, side);
    if(tomato_num == 1) angle = progress * 360.0 / 1500; // 每秒钟增加 0.24 度
    else angle = progress * 360.0 / 300;
    // 绘制背景圆
    painter.setPen(QPen(QColor(200, 200, 200), 25));
    painter.drawArc(rect, 0, 360 * 16);

    // 绘制进度圆弧
    QColor progressColor = (current_color == "background:#CD9B9B") ?
                            QColor(255, 102, 102): // 番茄色
                            QColor(102, 204, 0);  // 休息色
    painter.setPen(QPen(progressColor, 25, Qt::SolidLine, Qt::RoundCap));
    painter.drawArc(rect, 90 * 16, -angle * 16); // 从12点方向开始
    //qDebug()<<current_color;
}


void TomatoClock::mouseMoveEvent(QMouseEvent *e)
{
    if(e->buttons()&Qt::LeftButton)
        move(e->pos()+pos()-clickPos); //父窗口的左上角+当前鼠标指针移动-初始单击时候鼠标指针的方向
}

void TomatoClock::initTime()
{
    progress = 0;
    time.setHMS(0,0,0); //时间复位 0
    ui->Timer->display(time.toString("mm:ss"));
}

void TomatoClock::updateTime()
{
    //每次更新时间，time增加1
    time = time.addSecs(1);
    progress++;
    ui->Timer->display(time.toString("mm:ss"));


     // 触发重绘
    if(progress%10==0)
    {
        update();
        //qDebug()<<"paint";
    }
    if (time.minute() == 5 and tomato_num==0){
        //休息完毕，进入番茄钟
        initTime();
        tomato_num=1;
        current_color = "background:#CD9B9B";
        this->setStyleSheet(current_color);    //进入番茄色
    }else if(time.minute() == 25){
        //番茄钟完毕，进入休息时间
        tomato_num = 0;
        initTime();
        current_color = "background:#9BCD9B";
        this->setStyleSheet(current_color);    //进入休息色
    }
}


void TomatoClock::on_closeButton_clicked()
{
    emit windowClosed(); // 发射关闭信号
    close();
}

