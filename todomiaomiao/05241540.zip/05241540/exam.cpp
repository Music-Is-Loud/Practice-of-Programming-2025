#include "exam.h"
Exam::Exam(const QString& _name, const QDateTime& _baseTime, const QString& _details)
    :Event(_name, _baseTime, _details){}
